import express = require('express');
import cors = require('cors');
import parser = require('body-parser');
import cassandra = require('cassandra-driver');
import { uploadObject, getObject, uploadObjectChunks, getObjectChunks } from './controller/user.controller';
const app = express();
app.use(cors());
app.use(parser.urlencoded({ extended: false }));
app.use(parser.json());
// Configuration for cassandra 
const dbConfig = {
    contactPoints: ['127.0.0.1:9042'],
    // keyspace: app.get('keyspace'),
    keyspace: 'keyspace_localhost_1',
    localDataCenter: 'datacenter1'
}

// Cassandra instance created
export const db = new cassandra.Client(dbConfig);

// Connect to cassandra instance
db.connect().then(() => {
    console.log(`Local host count: ${db.hosts.length} && Keyspace is : ${db.keyspace}`);
})
    .catch((err) => {
        console.error(`Error: ${err}`);
    });


app.post('/api/user/upload', uploadObject);
app.get('/api/user/upload', getObject);
app.post('/api/user/upload-chunk', uploadObjectChunks);
app.get('/api/user/upload-chunk', getObjectChunks);

export default app;