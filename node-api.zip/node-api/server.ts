import app from "./app";

app.set('port', 5001);
app.set('keyspace_1', 'keyspace_localhost_1');
app.set('datacenter1', 'datacenter1');


export const server = app.listen(app.get('port'), () => {
    console.log(`Listening on port ${app.get('port')}`);
});