import { db } from "../app";
import { readFileSync, writeFile, createReadStream, createWriteStream } from 'fs';
import { resolve } from 'path';

export const uploadObject = (req, res, next) => {

    const content = readFileSync(resolve(__dirname + '../../../files/' + 'profile.png'), 'base64');

    const objBuffer = new Buffer(content, 'base64')

    const query = 'INSERT INTO keyspace_localhost_1.chunkstore (object_id,chunk_id,data) VALUES(?,?,?);';
    const params = ["100", "1", objBuffer];
    db.execute(query, params, (err, result) => {
        if (!err) {
            console.log('Uploaded;')
            res.json({ 'status': 'uploaded !' });
        } else {
            console.log(err)
            res.json({ 'status': 'Error uploading file !!' });
        }
    })
}

export const getObject = (req, res, next) => {
    const query = "SELECT object_id,chunk_id,data FROM keyspace_localhost_1.chunkstore";
    db.execute(query, (error, result) => {
        if (!error) {
            if (result.rows.length > 0) {
                result.rows.forEach(file => {
                    writeFile('display-img.png', new Buffer(file.data, "base64"),
                        // writeFile(file.name + file.id + '.xlsx', new Buffer(file.object, "base64"),
                        (err) => {
                            if (!err) {
                                console.log('check restore folder!!')
                            }
                        });
                });
                res.json(result.rows);
            } else {
                res.json({ 'status': 'Result set empty !!' });
            }

        } else {
            console.error(error);
        }
    });
}

export const uploadObjectChunks = (req, res, next) => {

    const stream = createReadStream(resolve(__dirname + '../../../files/' + 'profile.png'), {
        'encoding': 'base64',
        'highWaterMark': 16 * 1024
    });
    let counter = 0;
    stream.on('data', (data) => {
        const objBuffer = new Buffer(data, 'base64');
        const query = 'INSERT INTO keyspace_localhost_1.chunkstore (object_id,chunk_id,data) VALUES(?,?,?);';
        const params = ["100", counter++ + "", objBuffer];
        db.execute(query, params, (err, result) => {
            if (!err) {
                console.log('Uploaded chunk;')
            } else {
                console.log(err)
                res.json({ 'status': 'Error uploading file !!' });
            }
        });
    });


    stream.on('end', () => {
        console.log('end')
        res.json({ 'status': 'uploaded !' });
    })
}

export const getObjectChunks = (req, res, next) => {
    const query = "SELECT object_id,chunk_id,data FROM keyspace_localhost_1.chunkstore where object_id ='100';";
    let mergeChunks = [];
    db.execute(query, (error, result) => {
        if (!error) {
            if (result.rows.length > 0) {
                result.rows.forEach(file => {
                    mergeChunks.push(file.data);
                });
                let imgBuffer = Buffer.concat(mergeChunks);

                writeFile('display-img-2.png', imgBuffer,
                    (err) => {
                        if (!err) {
                            console.log('check restore folder!!')
                        }
                    });
                res.json(imgBuffer);
            } else {
                res.json({ 'status': 'Result set empty !!' });
            }
        } else {
            console.error(error);
        }
    });
}

